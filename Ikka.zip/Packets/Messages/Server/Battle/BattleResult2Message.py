from Utils.Writer import Writer
from Database.DatabaseManager import DataBase
from Packets.Messages.Server.Login.LoginFailedMessage import LoginFailedMessage


class BattleResult2Message(Writer):

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 23456
        self.player = player

    def encode(self):
        brawler_trophies = self.player.brawlers_trophies[str(self.player.brawler_id)]
        brawler_trophies_for_rank = self.player.brawlers_trophies_in_rank[str(self.player.brawler_id)]
        exp_reward = [8, 6, 4]
        player_tokens_reward = [20, 15, 10]
        
        name = self.player.name
        tokens = 0
        trof = 0
        exp = 0

        if 0 <= brawler_trophies <= 49:
            win_val = 8
            lose_val = 0

        else:
            if 50 <= brawler_trophies <= 99:
                win_val = 8
                lose_val = -1

            if 100 <= brawler_trophies <= 199:
                win_val = 8
                lose_val = -2

            if 200 <= brawler_trophies <= 299:
                win_val = 8
                lose_val = -3

            if 300 <= brawler_trophies <= 399:
                win_val = 8
                lose_val = -4

            if 400 <= brawler_trophies <= 499:
                win_val = 8
                lose_val = -5

            if 500 <= brawler_trophies <= 599:
                win_val = 8
                lose_val = -6

            if 600 <= brawler_trophies <= 699:
                win_val = 8
                lose_val = -7

            if 700 <= brawler_trophies <= 799:
                win_val = 8
                lose_val = -8

            if 800 <= brawler_trophies <= 899:
                win_val = 7
                lose_val = -9

            if 900 <= brawler_trophies <= 999:
                win_val = 6
                lose_val = -10

            if 1000 <= brawler_trophies <= 1099:
                win_val = 5
                lose_val = -11

            if 1100 <= brawler_trophies <= 1199:
                win_val = 4
                lose_val = -12

            if brawler_trophies >= 1200:
                win_val = 3
                lose_val = -12

        if self.player.battle_result == 0:
            self.player.ThreeVSThree_wins += 1
            self.player.player_experience += exp_reward[0]
            if self.player.tokensdoubler > 0:
                if self.player.tokensdoubler <= player_tokens_reward[0]:
                     print("OLD", player_tokens_reward[0])
                     player_tokens_reward[0] += self.player.tokensdoubler
                     self.player.tokensdoubler = 0
                     self.player.brawl_boxes += player_tokens_reward[0]
                     DataBase.replaceValue(self, "tokensdoubler", self.player.tokensdoubler)
                     DataBase.replaceValue(self, "brawlBoxes", self.player.brawl_boxes)
                     tokens = player_tokens_reward[0]
                     print("NEW", player_tokens_reward[0])
                else:
                    print("OLD", player_tokens_reward[0])
                    self.player.tokensdoubler -= player_tokens_reward[0]
                    player_tokens_reward[0] += player_tokens_reward[0]
                    self.player.brawl_boxes += player_tokens_reward[0]
                    DataBase.replaceValue(self, "tokensdoubler", self.player.tokensdoubler)
                    DataBase.replaceValue(self, "brawlBoxes", self.player.brawl_boxes)
                    tokens = player_tokens_reward[0]
                    print("NEW", player_tokens_reward[0])
            else:
                print("OLD", player_tokens_reward[0])
                self.player.brawl_boxes += player_tokens_reward[0]
                tokens = player_tokens_reward[0]
                print("NEW", player_tokens_reward[0])
            self.player.trophies += win_val
            self.player.brawlers_trophies[str(self.player.brawler_id)] = brawler_trophies + win_val
            trof = win_val
            if self.player.brawlers_trophies_in_rank[str(self.player.brawler_id)] < self.player.brawlers_trophies[str(self.player.brawler_id)]:
                self.player.brawlers_trophies_in_rank[str(self.player.brawler_id)] = brawler_trophies_for_rank + win_val

            DataBase.replaceValue(self, 'brawlersTrophies', self.player.brawlers_trophies)
            DataBase.replaceValue(self, 'brawlersTrophiesForRank', self.player.brawlers_trophies_in_rank)
            DataBase.replaceValue(self, 'trophies', self.player.trophies)
            DataBase.replaceValue(self, '3vs3Wins', self.player.ThreeVSThree_wins)
            DataBase.replaceValue(self, 'playerExp', self.player.player_experience)
        else:
            trof = lose_val
            self.player.player_experience += exp_reward[2]
            if self.player.tokensdoubler > 0:
                if self.player.tokensdoubler <= player_tokens_reward[2]:
                     print("OLD", player_tokens_reward[2])
                     player_tokens_reward[2] += self.player.tokensdoubler
                     self.player.tokensdoubler = 0
                     self.player.brawl_boxes += player_tokens_reward[2]
                     DataBase.replaceValue(self, "tokensdoubler", self.player.tokensdoubler)
                     DataBase.replaceValue(self, "brawlBoxes", self.player.brawl_boxes)
                     print("NEW", player_tokens_reward[2])
                else:
                    print("OLD", player_tokens_reward[2])
                    self.player.tokensdoubler -= player_tokens_reward[2]
                    player_tokens_reward[2] += player_tokens_reward[2]
                    self.player.brawl_boxes += player_tokens_reward[2]
                    DataBase.replaceValue(self, "tokensdoubler", self.player.tokensdoubler)
                    DataBase.replaceValue(self, "brawlBoxes", self.player.brawl_boxes)
                    print("NEW", player_tokens_reward[2])
            else:
                print("OLD", player_tokens_reward[2])
                self.player.brawl_boxes += player_tokens_reward[2]
                print("NEW", player_tokens_reward[2])
            self.player.trophies -= lose_val
            self.player.brawlers_trophies[str(self.player.brawler_id)] = brawler_trophies + lose_val

            DataBase.replaceValue(self, 'brawlersTrophies', self.player.brawlers_trophies)
            DataBase.replaceValue(self, 'brawlersTrophiesForRank', self.player.brawlers_trophies_in_rank)
            DataBase.replaceValue(self, 'trophies', self.player.trophies)
            DataBase.replaceValue(self, 'playerExp', self.player.player_experience)
            

        self.writeVint(7) # Battle End Game Mode (2 = Showdown, 3 = Robo Rumble, 4 = Big Game, 5 = Duo Showdown, 6 = Boss Fight. Else is 3vs3)
        self.writeVint(0) # Result (Victory/Defeat/Draw/Rank Score)
        self.writeVint(player_tokens_reward[2]) # Tokens Gained
        self.writeVint(trof) # Trophies Result
        self.writeVint(0) # Power Play Points Gained
        self.writeVint(0) # Doubled Tokens
        self.writeVint(0) # Double Token Event
        self.writeVint(0) # Token Doubler Remaining
        self.writeVint(0) # Big Game/Robo Rumble Time and Boss Fight Level Cleared
        self.writeVint(0) # Epic Win Power Play Points Gained
        self.writeVint(0) # Championship Level Passed
        self.writeVint(0) # Challenge Reward Type (0 = Star Points, 1 = Star Tokens)
        self.writeVint(0) # Challenge Reward Ammount
        self.writeVint(0) # Championship Losses Left
        self.writeVint(0) # Championship Maximun Losses
        self.writeVint(0) # Coin Shower Event
        self.writeVint(16) # Battle Result Type ((-16)-(-1) = Power Play Battle End, 0-15 = Practice Battle End, 16-31 = Matchmaking Battle End, 32-47 = Friendly Game Battle End, 48-63  = Spectate and Replay Battle End, 64-79 = Championship Battle End)
        self.writeVint(0) # Championship Cleared and Beta Quests
        
        # Players Array
        self.writeVint(1) # Battle End Screen Players
        self.writeVint(1) # Player Team and Star Player Type
        self.writeScId(self.player.brawler_id, 0) # Player Brawler
        self.writeScId(29, 0) # Player Skin
        self.writeVint(self.player.brawlers_trophies[str(self.player.brawler_id)]) # Brawler Trophies
        self.writeVint(0) # Player Power Play Points
        self.writeVint(0) # Brawler Power Level
        self.writeBoolean(True) # Player HighID and LowID Array
        self.writeInt(0) # HighID
        self.writeInt(1) # LowID
        self.writeString(self.player.name) # Player Name
        self.writeVint(0) # Player Experience Level
        self.writeVint(28000000) # Player Profile Icon
        self.writeVint(43000000) # Player Name Color

        # Experience Array
        self.writeVint(2) # Count
        self.writeVint(0) # Normal Experience ID
        self.writeVint(exp_reward[0]) # Normal Experience Gained
        self.writeVint(8) # Star Player Experience ID
        self.writeVint(exp_reward[0]) # Star Player Experience Gained

        # Rank Up and Level Up Bonus Array
        self.writeVint(0) # Count

        # Trophies and Experience Bars Array
        self.writeVint(2) # Count
        self.writeVint(1) # Trophies Bar Milestone ID
        self.writeVint(self.player.brawlers_trophies[str(self.player.brawler_id)]) # Brawler Trophies
        self.writeVint(self.player.brawlers_trophies_in_rank[str(self.player.brawler_id)]) # Brawler Trophies for Rank
        self.writeVint(5) # Experience Bar Milestone ID
        self.writeVint(self.player.player_experience) # Player Experience
        self.writeVint(1337) # Player Experience for Level
        
        self.writeScId(28, 0)  # Player Profile Icon
        self.writeBoolean(False)  # Play Again