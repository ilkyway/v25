from Utils.Writer import Writer
from Database.DatabaseManager import DataBase
from Packets.Messages.Server.Login.LoginFailedMessage import LoginFailedMessage
class BattleResultMessage(Writer):

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 23456
        self.player = player

    def encode(self):
        

        brawler_trophies = self.player.brawlers_trophies[str(self.player.brawler_id)]
        brawler_trophies_for_rank = self.player.brawlers_trophies_in_rank[str(self.player.brawler_id)]

        exp_reward = [15, 12, 9, 6, 5, 4, 3, 2, 1, 0]
        win = 0

        if 0 <= brawler_trophies <= 49:
            win = 8
            rank_1_val = 10
            rank_2_val = 8
            rank_3_val = 7
            rank_4_val = 6
            rank_5_val = 4
            rank_6_val = 2
            rank_7_val = 2
            rank_8_val = 1
            rank_9_val = 0
            rank_10_val = 0

        else:
            if 50 <= brawler_trophies <= 99:
                win = 7
                rank_1_val = 10
                rank_2_val = 8
                rank_3_val = 7
                rank_4_val = 6
                rank_5_val = 3
                rank_6_val = 2
                rank_7_val = 2
                rank_8_val = 0
                rank_9_val = -1
                rank_10_val = -2

            if 100 <= brawler_trophies <= 199:
                win = 6
                rank_1_val = 10
                rank_2_val = 8
                rank_3_val = 7
                rank_4_val = 6
                rank_5_val = 3
                rank_6_val = 1
                rank_7_val = 0
                rank_8_val = -1
                rank_9_val = -2
                rank_10_val = -2

            if 200 <= brawler_trophies <= 299:
                win = 6
                rank_1_val = 10
                rank_2_val = 8
                rank_3_val = 6
                rank_4_val = 5
                rank_5_val = 3
                rank_6_val = 1
                rank_7_val = 0
                rank_8_val = -2
                rank_9_val = -3
                rank_10_val = -3

            if 300 <= brawler_trophies <= 399:
                win = 5
                rank_1_val = 10
                rank_2_val = 8
                rank_3_val = 6
                rank_4_val = 5
                rank_5_val = 2
                rank_6_val = 0
                rank_7_val = 0
                rank_8_val = -3
                rank_9_val = -4
                rank_10_val = -4

            if 400 <= brawler_trophies <= 499:
                win = 5
                rank_1_val = 10
                rank_2_val = 8
                rank_3_val = 6
                rank_4_val = 5
                rank_5_val = 2
                rank_6_val = -1
                rank_7_val = -2
                rank_8_val = -3
                rank_9_val = -5
                rank_10_val = -5

            if 500 <= brawler_trophies <= 599:
                win = 5
                rank_1_val = 10
                rank_2_val = 8
                rank_3_val = 6
                rank_4_val = 4
                rank_5_val = 2
                rank_6_val = -1
                rank_7_val = -2
                rank_8_val = -5
                rank_9_val = -6
                rank_10_val = -6

            if 600 <= brawler_trophies <= 699:
                win = 5
                rank_1_val = 10
                rank_2_val = 8
                rank_3_val = 6
                rank_4_val = 4
                rank_5_val = 1
                rank_6_val = -2
                rank_7_val = -2
                rank_8_val = -5
                rank_9_val = -7
                rank_10_val = -8

            if 700 <= brawler_trophies <= 799:
                win = 5
                rank_1_val = 10
                rank_2_val = 8
                rank_3_val = 6
                rank_4_val = 4
                rank_5_val = 1
                rank_6_val = -3
                rank_7_val = -4
                rank_8_val = -5
                rank_9_val = -8
                rank_10_val = -9

            if 800 <= brawler_trophies <= 899:
                win = 4
                rank_1_val = 9
                rank_2_val = 7
                rank_3_val = 5
                rank_4_val = 2
                rank_5_val = 0
                rank_6_val = -3
                rank_7_val = -4
                rank_8_val = -7
                rank_9_val = -9
                rank_10_val = -10

            if 900 <= brawler_trophies <= 999:
                win = 4
                rank_1_val = 8
                rank_2_val = 6
                rank_3_val = 4
                rank_4_val = 1
                rank_5_val = -1
                rank_6_val = -3
                rank_7_val = -6
                rank_8_val = -8
                rank_9_val = -10
                rank_10_val = -11

            if 1000 <= brawler_trophies <= 1099:
                win = 4
                rank_1_val = 6
                rank_2_val = 5
                rank_3_val = 3
                rank_4_val = 1
                rank_5_val = -2
                rank_6_val = -5
                rank_7_val = -6
                rank_8_val = -9
                rank_9_val = -11
                rank_10_val = -12

            if 1100 <= brawler_trophies <= 1199:
                win = 3
                rank_1_val = 5
                rank_2_val = 4
                rank_3_val = 1
                rank_4_val = 0
                rank_5_val = -2
                rank_6_val = -6
                rank_7_val = -7
                rank_8_val = -10
                rank_9_val = -12
                rank_10_val = -13

            if brawler_trophies >= 1200:
                win = 2
                rank_1_val = 5
                rank_2_val = 3
                rank_3_val = 0
                rank_4_val = -1
                rank_5_val = -2
                rank_6_val = -6
                rank_7_val = -8
                rank_8_val = -11
                rank_9_val = -12
                rank_10_val = -13

        self.player.player_experience += exp_reward[self.player.rank - 1]
        DataBase.replaceValue(self, 'playerExp', self.player.player_experience)
        if self.player.rank >= win:
            self.player.solo_wins += 1
            DataBase.replaceValue(self, 'soloWins', self.player.solo_wins)

        if self.player.rank == 1:
            self.player.trophies += rank_1_val
            self.player.brawlers_trophies[str(self.player.brawler_id)] = brawler_trophies + rank_1_val
            if self.player.brawlers_trophies_in_rank[str(self.player.brawler_id)] < self.player.brawlers_trophies[
                str(self.player.brawler_id)] and rank_1_val > 0:
                self.player.brawlers_trophies_in_rank[
                    str(self.player.brawler_id)] = brawler_trophies_for_rank + rank_1_val
            DataBase.replaceValue(self, 'brawlersTrophies', self.player.brawlers_trophies)
            DataBase.replaceValue(self, 'brawlersTrophiesForRank', self.player.brawlers_trophies_in_rank)
            DataBase.replaceValue(self, 'trophies', self.player.trophies)

        elif self.player.rank == 2:
            self.player.trophies += rank_2_val
            self.player.brawlers_trophies[str(self.player.brawler_id)] = brawler_trophies + rank_2_val
            if self.player.brawlers_trophies_in_rank[str(self.player.brawler_id)] < self.player.brawlers_trophies[
                str(self.player.brawler_id)] and rank_2_val > 0:
                self.player.brawlers_trophies_in_rank[
                    str(self.player.brawler_id)] = brawler_trophies_for_rank + rank_2_val
            DataBase.replaceValue(self, 'brawlersTrophies', self.player.brawlers_trophies)
            DataBase.replaceValue(self, 'brawlersTrophiesForRank', self.player.brawlers_trophies_in_rank)
            DataBase.replaceValue(self, 'trophies', self.player.trophies)

        elif self.player.rank == 3:
            self.player.trophies += rank_3_val
            self.player.brawlers_trophies[str(self.player.brawler_id)] = brawler_trophies + rank_3_val
            if self.player.brawlers_trophies_in_rank[str(self.player.brawler_id)] < self.player.brawlers_trophies[
                str(self.player.brawler_id)] and rank_3_val > 0:
                self.player.brawlers_trophies_in_rank[
                    str(self.player.brawler_id)] = brawler_trophies_for_rank + rank_3_val
            DataBase.replaceValue(self, 'brawlersTrophies', self.player.brawlers_trophies)
            DataBase.replaceValue(self, 'brawlersTrophiesForRank', self.player.brawlers_trophies_in_rank)
            DataBase.replaceValue(self, 'trophies', self.player.trophies)

        elif self.player.rank == 4:
            self.player.trophies += rank_4_val
            self.player.brawlers_trophies[str(self.player.brawler_id)] = brawler_trophies + rank_4_val
            if self.player.brawlers_trophies_in_rank[str(self.player.brawler_id)] < self.player.brawlers_trophies[
                str(self.player.brawler_id)] and rank_4_val > 0:
                self.player.brawlers_trophies_in_rank[
                    str(self.player.brawler_id)] = brawler_trophies_for_rank + rank_4_val
            DataBase.replaceValue(self, 'brawlersTrophies', self.player.brawlers_trophies)
            DataBase.replaceValue(self, 'brawlersTrophiesForRank', self.player.brawlers_trophies_in_rank)
            DataBase.replaceValue(self, 'trophies', self.player.trophies)

        elif self.player.rank == 5:
            self.player.trophies += rank_5_val
            self.player.brawlers_trophies[str(self.player.brawler_id)] = brawler_trophies + rank_5_val
            if self.player.brawlers_trophies_in_rank[str(self.player.brawler_id)] < self.player.brawlers_trophies[
                str(self.player.brawler_id)] and rank_5_val > 0:
                self.player.brawlers_trophies_in_rank[
                    str(self.player.brawler_id)] = brawler_trophies_for_rank + rank_5_val
            DataBase.replaceValue(self, 'brawlersTrophies', self.player.brawlers_trophies)
            DataBase.replaceValue(self, 'brawlersTrophiesForRank', self.player.brawlers_trophies_in_rank)
            DataBase.replaceValue(self, 'trophies', self.player.trophies)

        elif self.player.rank == 6:
            self.player.trophies += rank_6_val
            self.player.brawlers_trophies[str(self.player.brawler_id)] = brawler_trophies + rank_6_val
            if self.player.brawlers_trophies_in_rank[str(self.player.brawler_id)] < self.player.brawlers_trophies[
                str(self.player.brawler_id)] and rank_6_val > 0:
                self.player.brawlers_trophies_in_rank[
                    str(self.player.brawler_id)] = brawler_trophies_for_rank + rank_6_val
            DataBase.replaceValue(self, 'brawlersTrophies', self.player.brawlers_trophies)
            DataBase.replaceValue(self, 'brawlersTrophiesForRank', self.player.brawlers_trophies_in_rank)
            DataBase.replaceValue(self, 'trophies', self.player.trophies)

        elif self.player.rank == 7:
            self.player.trophies += rank_7_val
            self.player.brawlers_trophies[str(self.player.brawler_id)] = brawler_trophies + rank_7_val
            if self.player.brawlers_trophies_in_rank[str(self.player.brawler_id)] < self.player.brawlers_trophies[
                str(self.player.brawler_id)] and rank_7_val > 0:
                self.player.brawlers_trophies_in_rank[
                    str(self.player.brawler_id)] = brawler_trophies_for_rank + rank_7_val
            DataBase.replaceValue(self, 'brawlersTrophies', self.player.brawlers_trophies)
            DataBase.replaceValue(self, 'brawlersTrophiesForRank', self.player.brawlers_trophies_in_rank)
            DataBase.replaceValue(self, 'trophies', self.player.trophies)

        elif self.player.rank == 8:
            self.player.trophies += rank_8_val
            self.player.brawlers_trophies[str(self.player.brawler_id)] = brawler_trophies + rank_8_val
            if self.player.brawlers_trophies_in_rank[str(self.player.brawler_id)] < self.player.brawlers_trophies[
                str(self.player.brawler_id)] and rank_8_val > 0:
                self.player.brawlers_trophies_in_rank[
                    str(self.player.brawler_id)] = brawler_trophies_for_rank + rank_8_val
            DataBase.replaceValue(self, 'brawlersTrophies', self.player.brawlers_trophies)
            DataBase.replaceValue(self, 'brawlersTrophiesForRank', self.player.brawlers_trophies_in_rank)
            DataBase.replaceValue(self, 'trophies', self.player.trophies)

        elif self.player.rank == 9:
            self.player.trophies += rank_9_val
            self.player.brawlers_trophies[str(self.player.brawler_id)] = brawler_trophies + rank_9_val
            if self.player.brawlers_trophies_in_rank[str(self.player.brawler_id)] < self.player.brawlers_trophies[
                str(self.player.brawler_id)] and rank_9_val > 0:
                self.player.brawlers_trophies_in_rank[
                    str(self.player.brawler_id)] = brawler_trophies_for_rank + rank_9_val
            DataBase.replaceValue(self, 'brawlersTrophies', self.player.brawlers_trophies)
            DataBase.replaceValue(self, 'brawlersTrophiesForRank', self.player.brawlers_trophies_in_rank)
            DataBase.replaceValue(self, 'trophies', self.player.trophies)

        elif self.player.rank == 10:
            self.player.trophies += rank_10_val
            self.player.brawlers_trophies[str(self.player.brawler_id)] = brawler_trophies + rank_10_val
            if self.player.brawlers_trophies_in_rank[str(self.player.brawler_id)] < self.player.brawlers_trophies[
                str(self.player.brawler_id)] and rank_10_val > 0:
                self.player.brawlers_trophies_in_rank[
                    str(self.player.brawler_id)] = brawler_trophies_for_rank + rank_10_val
            DataBase.replaceValue(self, 'brawlersTrophies', self.player.brawlers_trophies)
            DataBase.replaceValue(self, 'brawlersTrophiesForRank', self.player.brawlers_trophies_in_rank)
            DataBase.replaceValue(self, 'trophies', self.player.trophies)

        self.writeVint(0) # Battle End Game Mode (2 = Showdown, 3 = Robo Rumble, 4 = Big Game, 5 = Duo Showdown, 6 = Boss Fight. Else is 3vs3)
        self.writeVint(0) # Result (Victory/Defeat/Draw/Rank Score)
        self.writeVint(0) # Tokens Gained
        self.writeVint(0) # Trophies Result
        self.writeVint(0) # Power Play Points Gained
        self.writeVint(0) # Doubled Tokens
        self.writeVint(0) # Double Token Event
        self.writeVint(0) # Token Doubler Remaining
        self.writeVint(0) # Big Game/Robo Rumble Time and Boss Fight Level Cleared
        self.writeVint(0) # Epic Win Power Play Points Gained
        self.writeVint(0) # Championship Level Passed
        self.writeVint(0) # Challenge Reward Type (0 = Star Points, 1 = Star Tokens)
        self.writeVint(0) # Challenge Reward Ammount
        self.writeVint(0) # Championship Losses Left
        self.writeVint(0) # Championship Maximun Losses
        self.writeVint(0) # Coin Shower Event
        self.writeVint(32) # Battle Result Type ((-16)-(-1) = Power Play Battle End, 0-15 = Practice Battle End, 16-31 = Matchmaking Battle End, 32-47 = Friendly Game Battle End, 48-63  = Spectate and Replay Battle End, 64-79 = Championship Battle End)
        self.writeVint(0) # Championship Cleared and Beta Quests
        
        # Players Array
        self.writeVint(1) # Battle End Screen Players
        self.writeVint(1) # Player Team and Star Player Type
        self.writeScId(16, 0) # Player Brawler
        self.writeScId(29, 0) # Player Skin
        self.writeVint(0) # Brawler Trophies
        self.writeVint(0) # Player Power Play Points
        self.writeVint(0) # Brawler Power Level
        self.writeBoolean(True) # Player HighID and LowID Array
        self.writeInt(0) # HighID
        self.writeInt(1) # LowID
        self.writeString("Ilkka Squad") # Player Name
        self.writeVint(0) # Player Experience Level
        self.writeVint(28000000) # Player Profile Icon
        self.writeVint(43000000) # Player Name Color

        # Experience Array
        self.writeVint(2) # Count
        self.writeVint(0) # Normal Experience ID
        self.writeVint(0) # Normal Experience Gained
        self.writeVint(8) # Star Player Experience ID
        self.writeVint(0) # Star Player Experience Gained

        # Rank Up and Level Up Bonus Array
        self.writeVint(0) # Count

        # Trophies and Experience Bars Array
        self.writeVint(2) # Count
        self.writeVint(1) # Trophies Bar Milestone ID
        self.writeVint(0) # Brawler Trophies
        self.writeVint(0) # Brawler Trophies for Rank
        self.writeVint(5) # Experience Bar Milestone ID
        self.writeVint(0) # Player Experience
        self.writeVint(0) # Player Experience for Level
        
        self.writeScId(28, 0)  # Player Profile Icon
        self.writeBoolean(False)  # Play Again