from Packets.Messages.Server.AuthorCode.ChangeCode import ChangeCode

from Utils.Reader import BSMessageReader


class ClientChangeCode(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.high_id = self.read_int()
        self.low_id = self.read_int()


    def process(self):
        ChangeCode(self.client, self.player).send()